

library(haven)
x = read_sav("C:/Users/rahul/Downloads/Maharastra.sav")
# Install and load the required package

# Step 1: Create a subset with the needed columns
x1 <- x[, c("B6$01", "V107", "M55$1")]
# Step 2: Rename columns for easier handling
names(x1) <- c("B6_01", "V107", "M55_1")
# Step 3: Remove missing values
x1_clean <- na.omit(x1)
# Step 4: Partial correlation between B6_01 and V107 controlling for M55_1
pcor1 <- pcor.test(x1_clean$B6_01, x1_clean$V107, x1_clean$M55_1)
# Step 5: Partial correlation between B6_01 and M55_1 controlling for V107
pcor2 <- pcor.test(x1_clean$B6_01, x1_clean$M55_1, x1_clean$V107)
# Step 6: Display results
cat("Partial correlation between B6_01 and V107 controlling for M55_1:\n")
print(pcor1)
cat("\nPartial correlation between B6_01 and M55_1 controlling for V107:\n")
print(pcor2)