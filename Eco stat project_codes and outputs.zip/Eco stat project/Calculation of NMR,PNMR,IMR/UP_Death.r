library(haven)
x = read_sav("C:/Users/rahul/Downloads/UP.sav")
# 1st child calculation (living ,death(Neonatal mortality,Post neonatal mortality,Infant mortality)
c1 = x["B5$01"]
c1_clean = na.omit(c1)
l1 = sum(c1_clean)
d1 = x["B6$01"]
d1_clean = na.omit(d1)
NM1 = length(d1_clean[d1_clean <= 128])
PNM1 = length(d1_clean[(d1_clean <= 212 & d1_clean >=200) | d1_clean ==129 | d1_clean == 130])
IM1 = length(d1_clean[d1_clean <= 212])
# 2nd child calculation (living ,death(Neonatal mortality,Post neonatal mortality,Infant mortality)
c2 = x["B5$02"]
c2_clean = na.omit(c2)
l2 = sum(c2_clean)
d2 = x["B6$02"]
d2_clean = na.omit(d2)
NM2 = length(d2_clean[d2_clean <= 128])
PNM2 = length(d2_clean[(d2_clean <= 212 & d2_clean >=200) | d2_clean ==129 | d2_clean == 130])
IM2 = length(d2_clean[d2_clean <= 212])
# 3rd child calculation (living ,death(Neonatal mortality,Post neonatal mortality,Infant mortality)
c3 = x["B5$03"]
c3_clean = na.omit(c3)
l3 = sum(c3_clean)
d3 = x["B6$03"]
d3_clean = na.omit(d3)
NM3 = length(d3_clean[d3_clean <= 128])
PNM3 = length(d3_clean[(d3_clean <= 212 & d3_clean >=200) | d3_clean ==129 | d3_clean == 130])
IM3 = length(d3_clean[d3_clean <= 212])
# 4th child calculation (living ,death(Neonatal mortality,Post neonatal mortality,Infant mortality)
c4 = x["B5$04"]
c4_clean = na.omit(c4)
l4 = sum(c4_clean)
d4 = x["B6$04"]
d4_clean = na.omit(d4)
NM4 = length(d4_clean[d4_clean <= 128])
PNM4 = length(d4_clean[(d4_clean <= 212 & d4_clean >=200) | d4_clean ==129 | d4_clean == 130])
IM4 = length(d4_clean[d4_clean <= 212])
# 5th child calculation (living ,death(Neonatal mortality,Post neonatal mortality,Infant mortality)
c5 = x["B5$05"]
c5_clean = na.omit(c5)
l5 = sum(c5_clean)
d5 = x["B6$05"]
d5_clean = na.omit(d5)
NM5 = length(d5_clean[d5_clean <= 128])
PNM5 = length(d5_clean[(d5_clean <= 212 & d5_clean >=200) | d5_clean ==129 | d5_clean == 130])
IM5 = length(d5_clean[d5_clean <= 212])
# 6th child calculation (living ,death(Neonatal mortality,Post neonatal mortality,Infant mortality)
c6 = x["B5$06"]
c6_clean = na.omit(c6)
l6 = sum(c6_clean)
d6 = x["B6$06"]
d6_clean = na.omit(d6)
NM6 = length(d6_clean[d6_clean <= 128])
PNM6 = length(d6_clean[(d6_clean <= 212 & d6_clean >=200) | d6_clean ==129 | d6_clean == 130])
IM6 = length(d6_clean[d6_clean <= 212])
# 7th child calculation (living ,death(Neonatal mortality,Post neonatal mortality,Infant mortality)
c7 = x["B5$07"]
c7_clean = na.omit(c7)
l7 = sum(c7_clean)
d7 = x["B6$07"]
d7_clean = na.omit(d7)
NM7 = length(d7_clean[d7_clean <= 128])
PNM7 = length(d7_clean[(d7_clean <= 212 & d7_clean >=200) | d7_clean ==129 | d7_clean == 130])
IM7 = length(d7_clean[d7_clean <= 212])
# 8th child calculation (living ,death(Neonatal mortality,Post neonatal mortality,Infant mortality)
c8 = x["B5$08"]
c8_clean = na.omit(c8)
l8 = sum(c8_clean)
d8 = x["B6$08"]
d8_clean = na.omit(d8)
NM8 = length(d8_clean[d8_clean <= 128])
PNM8 = length(d8_clean[(d8_clean <= 212 & d8_clean >=200) | d8_clean ==129 | d8_clean == 130])
IM8 = length(d8_clean[d8_clean <= 212])
# 9th child calculation (living ,death(Neonatal mortality,Post neonatal mortality,Infant mortality)
c9 = x["B5$09"]
c9_clean = na.omit(c9)
l9 = sum(c9_clean)
d9 = x["B6$09"]
d9_clean = na.omit(d9)
NM9 = length(d9_clean[d9_clean <= 128])
PNM9 = length(d9_clean[(d9_clean <= 212 & d9_clean >=200) | d9_clean ==129 | d9_clean == 130])
IM9 = length(d9_clean[d9_clean <= 212])
# 10th child calculation (living ,death(Neonatal mortality,Post neonatal mortality,Infant mortality)
c10 = x["B5$10"]
c10_clean = na.omit(c10)
l10 = sum(c10_clean)
d10 = x["B6$10"]
d10_clean = na.omit(d10)
NM10 = length(d10_clean[d10_clean <= 128])
PNM10 = length(d10_clean[(d10_clean <= 212 & d10_clean >=200) | d10_clean ==129 | d10_clean == 130])
IM10 = length(d10_clean[d10_clean <= 212])
# 11th child calculation (living ,death(Neonatal mortality,Post neonatal mortality,Infant mortality)
c11 = x["B5$11"]
c11_clean = na.omit(c11)
l11 = sum(c11_clean)
d11 = x["B6$11"]
d11_clean = na.omit(d11)
NM11 = length(d11_clean[d11_clean <= 128])
PNM11 = length(d11_clean[(d11_clean <= 212 & d11_clean >=200) | d11_clean ==129 | d11_clean == 130])
IM11 = length(d11_clean[d11_clean <= 212])
# 12th child calculation (living ,death(Neonatal mortality,Post neonatal mortality,Infant mortality)
c12 = x["B5$12"]
c12_clean = na.omit(c12)
l12 = sum(c12_clean)
d12 = x["B6$12"]
d12_clean = na.omit(d12)
NM12 = length(d12_clean[d12_clean <= 128])
PNM12 = length(d12_clean[(d12_clean <= 212 & d12_clean >=200) | d12_clean ==129 | d12_clean == 130])
IM12 = length(d12_clean[d12_clean <= 212])
# 13th child calculation (living ,death(Neonatal mortality,Post neonatal mortality,Infant mortality)
c13 = x["B5$13"]
c13_clean = na.omit(c13)
l13 = sum(c13_clean)
d13 = x["B6$13"]
d13_clean = na.omit(d13)
NM13 = length(d13_clean[d13_clean <= 128])
PNM13 = length(d13_clean[(d13_clean <= 212 & d13_clean >=200) | d13_clean ==129 | d13_clean == 130])
IM13 = length(d13_clean[d13_clean <= 212])
# 14th child calculation (living ,death(Neonatal mortality,Post neonatal mortality,Infant mortality)
c14 = x["B5$14"]
c14_clean = na.omit(c14)
l14 = sum(c14_clean)
d14 = x["B6$14"]
d14_clean = na.omit(d14)
NM14 = length(d14_clean[d14_clean <= 128])
PNM14 = length(d14_clean[(d14_clean <= 212 & d14_clean >=200) | d14_clean ==129 | d14_clean == 130])
IM14 = length(d14_clean[d14_clean <= 212])
# 15th child calculation (living ,death(Neonatal mortality,Post neonatal mortality,Infant mortality)
c15 = x["B5$15"]
c15_clean = na.omit(c15)
l15 = sum(c15_clean)
d15 = x["B6$15"]
d15_clean = na.omit(d15)
NM15 = length(d15_clean[d15_clean <= 128])
PNM15 = length(d15_clean[(d15_clean <= 212 & d15_clean >=200) | d15_clean ==129 | d15_clean == 130])
IM15 = length(d15_clean[d15_clean <= 212])
# 16th child calculation (living ,death(Neonatal mortality,Post neonatal mortality,Infant mortality)
c16 = x["B5$16"]
c16_clean = na.omit(c16)
l16 = sum(c16_clean)
d16 = x["B6$16"]
d16_clean = na.omit(d16)
NM16 = length(d16_clean[d16_clean <= 128])
PNM16 = length(d16_clean[(d16_clean <= 212 & d16_clean >=200) | d16_clean ==129 | d16_clean == 130])
IM16 = length(d16_clean[d16_clean <= 212])
# 17th child calculation (living ,death(Neonatal mortality,Post neonatal mortality,Infant mortality)
c17 = x["B5$17"]
c17_clean = na.omit(c17)
l17 = sum(c17_clean)
d17 = x["B6$17"]
d17_clean = na.omit(d17)
NM17 = length(d17_clean[d17_clean <= 128])
PNM17 = length(d17_clean[(d17_clean <= 212 & d17_clean >=200) | d17_clean ==129 | d17_clean == 130])
IM17 = length(d17_clean[d17_clean <= 212])
# 18th child calculation (living ,death(Neonatal mortality,Post neonatal mortality,Infant mortality)
c18 = x["B5$18"]
c18_clean = na.omit(c18)
l18 = sum(c18_clean)
d18 = x["B6$18"]
d18_clean = na.omit(d18)
NM18 = length(d18_clean[d18_clean <= 128])
PNM18 = length(d18_clean[(d18_clean <= 212 & d18_clean >=200) | d18_clean ==129 | d18_clean == 130])
IM18 = length(d18_clean[d18_clean <= 212])
# 19th child calculation (living ,death(Neonatal mortality,Post neonatal mortality,Infant mortality)
c19 = x["B5$19"]
c19_clean = na.omit(c19)
l19 = sum(c19_clean)
d19 = x["B6$19"]
d19_clean = na.omit(d19)
NM19 = length(d19_clean[d19_clean <= 128])
PNM19 = length(d19_clean[(d19_clean <= 212 & d19_clean >=200) | d19_clean ==129 | d19_clean == 130])
IM19 = length(d19_clean[d19_clean <= 212])
# 20th child calculation (living ,death(Neonatal mortality,Post neonatal mortality,Infant mortality)
c20 = x["B5$20"]
c20_clean = na.omit(c20)
l20 = sum(c20_clean)
d20 = x["B6$20"]
d20_clean = na.omit(d20)
NM20 = length(d20_clean[d20_clean <= 128])
PNM20 = length(d20_clean[(d20_clean <= 212 & d20_clean >=200) | d20_clean ==129 | d20_clean == 130])
IM20 = length(d20_clean[d20_clean <= 212])
l = l1+l2+l3+l4+l5+l6+l7+l8+l9+l10+l11+l12+l13+l14+l15+l16+l17+l18+l19+l20
NM = NM1+NM2+NM3+NM4+NM5+NM6+NM7+NM8+NM9+NM10+NM11+NM12+NM13+NM14+NM15+NM16+NM17+NM18+NM19+NM20
PNM = PNM1+PNM2+PNM3+PNM4+PNM5+PNM6+PNM7+PNM8+PNM9+PNM10+PNM11+PNM12+PNM13+PNM14+PNM15+PNM16+PNM17+PNM18+PNM19+PNM20
IM = IM1+IM2+IM3+IM4+IM5+IM6+IM7+IM8+IM9+IM10+IM11+IM12+IM13+IM14+IM15+IM16+IM17+IM18+IM19+IM20
NMR_UP = NM/l *1000
PNMR_UP = PNM/l *1000
IMR_UP = IM/l *1000
NMR_UP
PNMR_UP 
IMR_UP 

