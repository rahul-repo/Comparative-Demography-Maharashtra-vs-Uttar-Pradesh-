library(haven) 
x = read_sav("C:/Users/rahul/Downloads/Maharastra.sav")
xA = x["M55A$1"]
xA_clean = na.omit(xA)
sum(xA_clean)
xB = x["M55B$1"]
xB_clean = na.omit(xB)
sum(xB_clean)
xC = x["M55C$1"]
xC_clean = na.omit(xC)
sum(xC_clean)
xD = x["M55D$1"]
xD_clean = na.omit(xD)
sum(xD_clean)
xE = x["M55E$1"]
xE_clean = na.omit(xE)
sum(xE_clean)
xF = x["M55F$1"]
xF_clean = na.omit(xF)
sum(xF_clean)
xG = x["M55G$1"]
xG_clean = na.omit(xG)
sum(xG_clean)
xH = x["M55H$1"]
xH_clean = na.omit(xH)
sum(xH_clean)
xI = x["M55I$1"]
xI_clean = na.omit(xI)
sum(xI_clean)
xJ = x["M55J$1"]
xJ_clean = na.omit(xJ)
sum(xJ_clean)
xK = x["M55K$1"]
xK_clean = na.omit(xK)
sum(xK_clean)
xL = x["M55L$1"]
xL_clean = na.omit(xL)
sum(xL_clean)
# Take the top 5 
L = c(sum(xA_clean),sum(xB_clean),sum(xC_clean),sum(xD_clean),sum(xE_clean),sum(xF_clean),sum(xG_clean),sum(xH_clean),sum(xI_clean),sum(xJ_clean),sum(xK_clean),sum(xL_clean))
top5 <- sort(L, decreasing = TRUE)[1:5]
top5
#Find the correlation
xA = x[,c("B5$01","M55A$1")]
xA_clean = na.omit(xA)
corA_Maharashtra = cor(xA_clean["B5$01"],xA_clean["M55A$1"])
xB = x[,c("B5$01","M55B$1")]
xB_clean = na.omit(xB)
corB_Maharashtra = cor(xB_clean["B5$01"],xB_clean["M55B$1"])
xC = x[,c("B5$01","M55C$1")]
xC_clean = na.omit(xC)
corC_Maharashtra = cor(xC_clean["B5$01"],xC_clean["M55C$1"])
xG = x[,c("B5$01","M55G$1")]
xG_clean = na.omit(xG)
corG_Maharashtra = cor(xG_clean["B5$01"],xG_clean["M55G$1"])
xI = x[,c("B5$01","M55I$1")]
xI_clean = na.omit(xI)
corI_Maharashtra = cor(xI_clean["B5$01"],xI_clean["M55I$1"])




 
 