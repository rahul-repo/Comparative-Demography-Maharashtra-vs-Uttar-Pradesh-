# Load necessary package
library(haven)

# Read dataset (change path if needed)
x <- read_sav("C:/Users/rahul/Downloads/UP.sav")

# Select relevant variables
data <- x[, c("B5$01", "M55$1", "V107")]

# Remove rows with missing values
data_clean <- na.omit(data)

# Ensure dependent variable is numeric (0/1)
data_clean$`B5$01` <- as.numeric(data_clean$`B5$01`)

# Check coding
table(data_clean$`B5$01`)

# Fit logistic regression model
model <- glm(`B5$01` ~ `M55$1` + `V107`, data = data_clean, family = binomial)

# View summary of model
summary(model)

# Get odds ratios
exp(coef(model))

# Get 95% confidence intervals for odds ratios
exp(confint(model))

# Predict probabilities
data_clean$predicted_prob <- predict(model, type = "response")

# Convert probabilities to binary classification (threshold = 0.5)
data_clean$predicted_class <- ifelse(data_clean$predicted_prob > 0.5, 1, 0)

# Confusion matrix
table(Predicted = data_clean$predicted_class, Actual = data_clean$`B5$01`)

# Model accuracy
accuracy <- mean(data_clean$predicted_class == data_clean$`B5$01`)
print(paste("Model Accuracy:", round(accuracy, 3)))
